% set number of hours to delay onset of raw to mat conversion
hours         = 1; 
% directories
ext           = '.raw';
scriptsFolder = 'C:\Users\alexd\OneDrive - University Of Cambridge\Cam\PhD\Project\Data&CodeBackup\Scripts\Alex-PhD\file_conversion';

% inputFolder   = 'C:\Users\alexd\Dropbox (Cambridge University)\NOG MEA Data\MEA Data Mecp2 Project Jan 2019-\RAW files';
% outputFolder  = 'C:\Users\alexd\Dropbox (Cambridge University)\NOG MEA Data\MEA Data Mecp2 Project Jan 2019-\MAT files';

inputFolder   = 'G:\MC_Rack Data\RAW files';
outputFolder  = 'G:\MC_Rack Data\MAT files';

% inputFolder   = 'F:\Alex\RAW files';
% outputFolder  = 'F:\Alex\MAT files';

cd(scriptsFolder);
addpath(genpath(scriptsFolder));
%% create timer
% input #2 to below timer function is the delay in s
T = timer('StartDelay',hours*60*60,'TimerFcn',...
    @(src,evt)MEAbatchConvert_20210304(ext,inputFolder,outputFolder,scriptsFolder)); 
% run
start(T)
